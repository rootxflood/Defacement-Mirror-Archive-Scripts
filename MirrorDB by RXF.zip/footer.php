<footer>      
  <p>
                    <!-- Copyright info --> </p><center><a href="index.php" type="button" class="btn btn-primary"> © Mirror-DB 2015 - Unrestricted Information</a>
                  <a href="https://www.facebook.com/MirrorDB" type="button" class="btn btn-info">Contact Us</a> <a href="https://www.facebook.com/profile.php?id=100000907275583" type="button" class="btn btn-danger"> By Root_X_FlooD</a>-
</center>           <p></p>
           

            </footer>